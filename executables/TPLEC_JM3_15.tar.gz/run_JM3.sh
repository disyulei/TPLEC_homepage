#########################################################################
# File Name: run_JM3.sh
# Author: Yibo Lin
# mail: yibolin@utexas.edu
# Created Time: Wed 30 Dec 2015 10:18:21 AM CST
#########################################################################
#!/bin/bash

# ==== Speedup + No-Stitch
./TPLEC_SPIE13   -inlib ISCAS_sim/sim_c1.ascii     -mindp 120   -simlg 2   -prslct 1   -usestitch 0 

# ==== Speedup + Stitch
#./TPLEC_SPIE13   -inlib ISCAS_sim/sim_c1.ascii     -mindp 120   -simlg 2   -prslct 1   -usestitch 1 

# ==== No-Speedup + No-Stitch
#./TPLEC_SPIE13   -inlib ISCAS_sim/sim_c1.ascii     -mindp 120   -simlg 1   -prslct 0   -usestitch 0 

# ==== No-Speedup + Stitch
#./TPLEC_SPIE13   -inlib ISCAS_sim/sim_c1.ascii     -mindp 120   -simlg 1   -prslct 0   -usestitch 1 
